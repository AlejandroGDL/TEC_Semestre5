<?php 
    if(isset($_POST['Delete'])){
        $ID = $_POST['ID_Producto'];

        $Borrar = "DELETE FROM Producto WHERE ID_Producto='$ID' ";
        $ejecutar = sqlsrv_query($conn,$Borrar);

        if($ejecutar){
            echo '<script type="text/javascript"> window.onload = function () { alert("Producto Eliminado Correctamente"); } </script>';
        } else{
            echo '<script type="text/javascript"> window.onload = function () { alert("Hubo un error al intentar eliminar el producto"); } </script>';
        }
    }
?>