<?php include('Codigos/conexion.php'); ?>

<Form method="GET" class="ModalForm_P">
    <section class="ModalContainer_P">
        <p>Todos los productos:</p>
        <?php include('Codigos/ShowAllProducts.php'); ?>
        <div class="Buttons_P">
            <a id="Divisor_P"></a>
            <a id="BtnCerrar_P">Cerrar</a>
        </div>
        
    </section>
</Form>