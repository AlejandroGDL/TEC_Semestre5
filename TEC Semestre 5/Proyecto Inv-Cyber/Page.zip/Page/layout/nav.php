<nav class="NavCompleto"> 
    <div class="nav">
        <a href="index.php"><button>Ventas<img src="icons/ShopCar_Dark.png" alt=""></button></a>
        <a id="Sep"></a>
        <a href="AddProduct.php"><button>Agregar<img src="icons/Add_Dark.png" alt=""></button></a>
        <a href="EditProduct.php"><button>Editar<img src="icons/Edit_Dark.png" alt=""></button></a>
        <a id="Sep"></a>
        <a href="DeleteProduct.php"><button>Eliminar <img src="icons/Delete_Dark.png" alt=""></button></a>
    </div>
    <!-- <a class="Divisor"></a> -->
</nav>
