<?php $Noti = "Este producto no existe" ?>
<section class="Noti_Form">
    <div class="Noti_Container">
        <div class="N_Header">
            <img src="Icons/Bell_White.png" alt="">
            <p>Advertencia</p>
        </div>
        <p class="Para_Container"><?php echo $Noti ?></p>
        <a id="N_Cerrar">Cerrar</a>
    </div>
</section>
